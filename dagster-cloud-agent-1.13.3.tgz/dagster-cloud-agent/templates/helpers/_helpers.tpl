{{/* vim: set filetype=mustache: */}}
{{/* Taken from dagster/templates/dagster-user-deployments */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "dagster.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dagster.fullname" -}}
{{- $fullnameOverride := .Values.fullnameOverride }}
{{- $nameOverride :=  .Values.nameOverride }}

{{- if .Values.global }}
{{- $fullnameOverride = .Values.global.fullnameOverride }}
{{- $nameOverride = .Values.global.nameOverride }}
{{- end }}

{{- if $fullnameOverride -}}
{{- $fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name $nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

# Image utils
{{- define "dagster.dagsterImage.name" }}
  {{- $ := index . 0 }}

  {{- with index . 1 }}
    {{- $tag := .tag | default $.Chart.Version }}
    {{- printf "%s:%s" .repository $tag }}
  {{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dagster.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "dagster.labels" -}}
helm.sh/chart: {{ include "dagster.chart" . }}
{{ include "dagster.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "dagster.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dagster.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "dagster.serviceAccountName" -}}
{{- .Values.serviceAccount.name | default (include "dagster.fullname" .) }}
{{- end -}}

{{/*
Defining the value of the DAGSTER_HOME env variable
*/}}
{{- define "dagster.home" -}}
/opt/dagster/dagster_home
{{- end -}}

{{/*
The configmap name of the Dagster instance
*/}}
{{- define "dagster.instanceConfigMapName" -}}
{{- (include "dagster.fullname" $) | printf "%s-instance" }}
{{- end -}}

{{- define "dagster.loggingConfigMapName" -}}
{{- (include "dagster.fullname" $) | printf "%s-logging" }}
{{- end -}}

{{- define "dagster.loggingPath" -}}
{{- include "dagster.home" $ }}/logging.yaml
{{- end -}}

{{/*
Derive the agent container name from the chart's name
*/}}
{{- define "agent.containerName" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}